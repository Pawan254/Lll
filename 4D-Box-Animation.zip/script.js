
const cube = document.querySelector('.cube');
let x = 0, y = 0;

document.addEventListener('mousemove', (e) => {
    x = (e.clientY / window.innerHeight - 0.5) * 360;
    y = (e.clientX / window.innerWidth - 0.5) * 360;
    cube.style.transform = `rotateX(${x}deg) rotateY(${y}deg)`;
});
    